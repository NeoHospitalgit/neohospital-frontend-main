// import React from "react";
// import List from "./List";
// import TopBarAdmin from "./TopBarAdmin";
// import { useEffect, useState } from "react";
// import { useAuth } from "../../store/auth";
// import { toast } from "react-toastify";
// import { useNavigate } from "react-router-dom";

// function Addblog() {
//   const [blogsData, setBlogsData] = useState({
//     blog_title: "",
//     blog_slug: "",
//     blog_date: "",
//     blog_auther: "",
//     blog_category: "",
//     blog_tags: "",
//     blog_image: null,
//     blog_content: "",
//     blog_seoTitle: "",
//     blog_metaDescription: "",
//     blog_imageALT: "",
//     blog_canonicalURL: "",
//     blog_additionalCode: "",
//     blog_metaKeyword: "",
//     blog_metaTitle: "",
//     Blog_whoIsAdded: "",
//     blog_status: "",
//   });

//   const { authorizationToken, API } = useAuth();

//   const navigate = useNavigate();

//   const handleBlogInput = (e) => {
//     let name = e.target.name;
//     let value = e.target.value;

//     if (name === "blog_slug") {
//       value = value.toLowerCase().replace(/\s+/g, "-");
//     }

//     // If the input field is "blog_canonicalURL", update it based on the title value
//     if (name === "blog_title") {
//       // Format the title to be suitable for a URL
//       const slug = value.toLowerCase().replace(/\s+/g, "-");
//       // Set the canonical URL to the formatted title
//       setBlogsData({
//         ...blogsData,
//         [name]: value,
//         blog_canonicalURL: slug,
//         blog_slug: slug,
//       });
//     } else {
//       setBlogsData({
//         ...blogsData,
//         [name]: value,
//       });
//     }
//   };

//   const handleFileChange = (e) => {
//     const file = e.target.files[0];
//     console.log(file, "blogimg - 52");
//     setBlogsData({
//       ...blogsData,
//       blog_image: file,
//     });
//   };
//   const handleBlogs = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch(`${API}/api/adminv3/blogs`, {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: authorizationToken,
//         },
//         body: JSON.stringify(blogsData),
//       });
//       if (response.ok) {
//         const data = await response.json();
//         console.log(data, "add blog-59");
//         toast.success("Blog added successfully");
//         setBlogsData({
//           blog_title: "",
//           blog_slug: "",
//           blog_date: "",
//           blog_auther: "",
//           blog_category: "",
//           blog_tags: "",
//           blog_image: null,
//           blog_content: "",
//           blog_seoTitle: "",
//           blog_metaDescription: "",
//           blog_imageALT: "",
//           blog_canonicalURL: "",
//           blog_additionalCode: "",
//           blog_metaKeyword: "",
//           blog_metaTitle: "",
//           Blog_whoIsAdded: "",
//           Blog_status: "",
//         });
//         navigate("/admin/view-blogs");
//       } else {
//         toast.error("Failed to add Blog");
//       }
//     } catch (error) {
//       toast.error("Blogs not Added");
//       console.log(error);
//     }
//   };

//   return (
//     <>
//       <TopBarAdmin />
//       <main>
//         <div className="container-fluid">
//           <div className="row">
//             <div className="col-md-3 adminleft">
//               <div>
//                 <List />
//               </div>
//             </div>
//             <div className="col-md-9 adminright">
//               <div className="addblog">
//                 <div>
//                   <div className="addblogform">
//                     <h2>Add Blog</h2>
//                     <form onSubmit={handleBlogs}>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label htmlFor="blog_title" className="form-label">
//                             Title
//                           </label>
//                           <input
//                             name="blog_title"
//                             autoComplete="off"
//                             value={blogsData.blog_title}
//                             onChange={handleBlogInput}
//                             id="blog_title"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label htmlFor="blog_slug" className="form-label">
//                             Slug
//                           </label>
//                           <input
//                             name="blog_slug"
//                             autoComplete="off"
//                             value={blogsData.blog_slug}
//                             onChange={handleBlogInput}
//                             id="blog_slug"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                       </div>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label htmlFor="blog_image" className="form-label">
//                             Image
//                           </label>
//                           <input
//                             name="blog_image"
//                             autoComplete="off"
//                             // value={blogsData.blog_image}
//                             onChange={handleFileChange}
//                             id="blog_image"
//                             required
//                             type="file"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label htmlFor="blog_imageALT" className="form-label">
//                             Image ALT
//                           </label>
//                           <input
//                             name="blog_imageALT"
//                             autoComplete="off"
//                             value={blogsData.blog_imageALT}
//                             onChange={handleBlogInput}
//                             id="blog_imageALT"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                       </div>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label htmlFor="blog_date" className="form-label">
//                             Date
//                           </label>
//                           <input
//                             name="blog_date"
//                             autoComplete="off"
//                             value={blogsData.blog_date}
//                             onChange={handleBlogInput}
//                             id="blog_date"
//                             required
//                             type="date"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label htmlFor="blog_auther" className="form-label">
//                             Auther
//                           </label>
//                           <input
//                             name="blog_auther"
//                             autoComplete="off"
//                             value={blogsData.blog_auther}
//                             onChange={handleBlogInput}
//                             id="blog_auther"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                       </div>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label htmlFor="blog_category" className="form-label">
//                             Category
//                           </label>
//                           <input
//                             name="blog_category"
//                             autoComplete="off"
//                             value={blogsData.blog_category}
//                             onChange={handleBlogInput}
//                             id="blog_category"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label htmlFor="blog_tags" className="form-label">
//                             Tags
//                           </label>
//                           <input
//                             name="blog_tags"
//                             autoComplete="off"
//                             value={blogsData.blog_tags}
//                             onChange={handleBlogInput}
//                             id="blog_tags"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                       </div>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label
//                             htmlFor="blog_metaTitle"
//                             className="form-label"
//                           >
//                             Meta Tittle
//                           </label>
//                           <input
//                             name="blog_metaTitle"
//                             autoComplete="off"
//                             value={blogsData.blog_metaTitle}
//                             onChange={handleBlogInput}
//                             id="blog_metaTitle"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label
//                             htmlFor="blog_metaDescription"
//                             className="form-label"
//                           >
//                             Meta Description
//                           </label>
//                           <input
//                             name="blog_metaDescription"
//                             autoComplete="off"
//                             value={blogsData.blog_metaDescription}
//                             onChange={handleBlogInput}
//                             id="blog_metaDescription"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                       </div>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label
//                             htmlFor="blog_canonicalURL"
//                             className="form-label"
//                           >
//                             Canonical URL
//                           </label>
//                           <input
//                             name="blog_canonicalURL"
//                             autoComplete="off"
//                             value={blogsData.blog_canonicalURL}
//                             onChange={handleBlogInput}
//                             id="blog_canonicalURL"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label
//                             htmlFor="blog_metaKeyword"
//                             className="form-label"
//                           >
//                             Meta Keyword
//                           </label>
//                           <input
//                             name="blog_metaKeyword"
//                             autoComplete="off"
//                             value={blogsData.blog_metaKeyword}
//                             onChange={handleBlogInput}
//                             id="blog_metaKeyword"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                       </div>
//                       <div className="row mt-4">
//                         <div className="col-md-6">
//                           <label htmlFor="blog_seoTitle" className="form-label">
//                             SEO TITLE
//                           </label>
//                           <input
//                             name="blog_seoTitle"
//                             autoComplete="off"
//                             value={blogsData.blog_seoTitle}
//                             onChange={handleBlogInput}
//                             id="blog_seoTitle"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="col-md-6">
//                           <label
//                             htmlFor="blog_additionalCode"
//                             className="form-label"
//                           >
//                             ADDITIONAL CODE
//                           </label>
//                           <input
//                             name="blog_additionalCode"
//                             autoComplete="off"
//                             value={blogsData.blog_additionalCode}
//                             onChange={handleBlogInput}
//                             id="blog_additionalCode"
//                             required
//                             type="text"
//                             className="form-control"
//                           />
//                         </div>
//                         <div className="row mt-4">
//                           <div className="col-md-12">
//                             <label
//                               htmlFor="blog_content"
//                               className="form-label"
//                             >
//                               Content
//                             </label>
//                             <div className="contentbox">
//                               <textarea
//                                 rows="6"
//                                 name="blog_content"
//                                 autoComplete="off"
//                                 value={blogsData.blog_content}
//                                 onChange={handleBlogInput}
//                                 id="blog_content"
//                                 required
//                                 type="text"
//                                 className="form-control"
//                               ></textarea>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="row mt-4">
//                           <div className="col-md-6">
//                             <label htmlFor="Blog_status" className="form-label">
//                               Blog Status
//                             </label>
//                             <select
//                               name="blog_status"
//                               autoComplete="off"
//                               value={blogsData.blog_status ? "1" : "0"}
//                               onChange={handleBlogInput}
//                               id="Blog_status"
//                               required
//                               className="form-control"
//                             >
//                               <option value="1">Active</option>
//                               <option value="0">Inactive</option>
//                             </select>
//                           </div>
//                           <div className="col-md-6">
//                             <label
//                               htmlFor="Blog_whoIsAdded"
//                               className="form-label"
//                             >
//                               Blog User
//                             </label>
//                             <input
//                               name="Blog_whoIsAdded"
//                               autoComplete="off"
//                               value={blogsData.Blog_whoIsAdded}
//                               // readOnly
//                               id="Blog_whoIsAdded"
//                               onChange={handleBlogInput}
//                               // required
//                               type="text"
//                               className="form-control"
//                             />
//                           </div>
//                         </div>
//                       </div>

//                       <div className="row mt-4">
//                         <div className="col-md-12">
//                           <button
//                             type="submit"
//                             className="btn btn-primary w-100"
//                           >
//                             Submit
//                           </button>
//                         </div>
//                       </div>
//                     </form>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </main>
//     </>
//   );
// }

// export default Addblog;
import React, { useState } from "react";
import { useAuth } from "../../store/auth";
import { useNavigate } from "react-router-dom";

function Addblog() {
  const [blogsData, setBlogsData] = useState({
    blog_title: "",
    blog_slug: "",
    blog_date: "",
    blog_auther: "",
    blog_category: "",
    blog_tags: "",
    blogImage: null,
    blog_content: "",
    blog_seoTitle: "",
    blog_metaDescription: "",
    blog_imageALT: "",
    blog_canonicalURL: "",
    blog_additionalCode: "",
    blog_metaKeyword: "",
    blog_metaTitle: "",
    Blog_whoIsAdded: "",
    blog_status: "",
  });

  const { authorizationToken, API } = useAuth();

  const navigate = useNavigate();

  const handleBlogInput = (e) => {
    let name = e.target.name;
    let value = e.target.value;

    if (name === "blog_slug") {
      value = value.toLowerCase().replace(/\s+/g, "-");
    }

    // If the input field is "blog_canonicalURL", update it based on the title value
    if (name === "blog_title") {
      // Format the title to be suitable for a URL
      const slug = value.toLowerCase().replace(/\s+/g, "-");
      // Set the canonical URL to the formatted title
      setBlogsData({
        ...blogsData,
        [name]: value,
        blog_canonicalURL: slug,
        blog_slug: slug,
      });
    } else {
      setBlogsData({
        ...blogsData,
        [name]: value,
      });
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    console.log(file, "blogimg - 52");
    setBlogsData({
      ...blogsData,
      blogImage: file,
    });
  };

  const handleBlogs = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      Object.keys(blogsData).forEach((key) => {
        formData.append(key, blogsData[key]);
      });
      const response = await fetch(`${API}/api/adminv3/blogs`, {
        method: "POST",
        headers: {
          Authorization: authorizationToken,
        },
        body: formData,
      });
      if (response.ok) {
        const data = await response.json();
        console.log(data, "add blog-59");
        alert("Blog added successfully");
        setBlogsData({
          blog_title: "",
          blog_slug: "",
          blog_date: "",
          blog_auther: "",
          blog_category: "",
          blog_tags: "",
          blogImage: null,
          blog_content: "",
          blog_seoTitle: "",
          blog_metaDescription: "",
          blog_imageALT: "",
          blog_canonicalURL: "",
          blog_additionalCode: "",
          blog_metaKeyword: "",
          blog_metaTitle: "",
          Blog_whoIsAdded: "",
          blog_status: "",
        });
        navigate("/admin/view-blogs");
      } else {
        alert("Failed to add Blog");
      }
    } catch (error) {
      alert("Blogs not Added");
      console.log(error);
    }
  };

  return (
    <>
      <main>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-3 adminleft">
              {/* List component here */}
            </div>
            <div className="col-md-9 adminright">
              <div className="addblog">
                <div className="addblogform">
                  <h2>Add Blog</h2>
                  <form onSubmit={handleBlogs} encType="multipart/form-data">
                    <div className="row mt-4">
                      <div className="col-md-6">
                        <label htmlFor="blog_title" className="form-label">
                          Title
                        </label>
                        <input
                          name="blog_title"
                          autoComplete="off"
                          value={blogsData.blog_title}
                          onChange={handleBlogInput}
                          id="blog_title"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="blog_slug" className="form-label">
                          Slug
                        </label>
                        <input
                          name="blog_slug"
                          autoComplete="off"
                          value={blogsData.blog_slug}
                          onChange={handleBlogInput}
                          id="blog_slug"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                    </div>
                    <div className="row mt-4">
                      <div className="col-md-6">
                        <label htmlFor="blogImage" className="form-label">
                          Image
                        </label>
                        <input
                          name="blogImage"
                          autoComplete="off"
                          onChange={handleFileChange}
                          id="blogImage"
                          required
                          type="file"
                          className="form-control"
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="blog_imageALT" className="form-label">
                          Image ALT
                        </label>
                        <input
                          name="blog_imageALT"
                          autoComplete="off"
                          value={blogsData.blog_imageALT}
                          onChange={handleBlogInput}
                          id="blog_imageALT"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                    </div>
                    {/* Rest of the form */}
                    <div className="row mt-4">
                      <div className="col-md-12">
                        <button type="submit" className="btn btn-primary w-100">
                          Add Blog
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default Addblog;
