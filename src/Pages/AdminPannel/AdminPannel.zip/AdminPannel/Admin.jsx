import React from "react";
import List from "./List";
import "./List.css";
import TopBarAdmin from "./TopBarAdmin";
function Admin() {
  return (
    <>
      <TopBarAdmin />
      <section>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-3 adminleft">
              <div>
                <List />
              </div>
            </div>
            <div className="col-md-9">
              <div className="row">
                <div className="col-md-4">
                  <div className="BlogDetails">
                    <h4>Blog Posted :</h4> <span>21</span>
                    <h4>Blog Pending : </h4> <span>3</span>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="SpecialtyDetails"></div>
                </div>
                <div className="col-md-4">
                  <div className="ServiceDetails"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Admin;
