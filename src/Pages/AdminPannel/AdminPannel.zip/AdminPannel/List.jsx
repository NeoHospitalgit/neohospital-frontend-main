import React, { useState } from "react";
import { Link } from "react-router-dom";
import logo from "../../Assets/index/logo.png";
import "./List.css";

function List() {
  const [openMenu, setOpenMenu] = useState(null);

  const toggleSubMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  return (
    <div className="AdminList">
      <div>
        <div className="text-center">
          <img src={logo} alt="Logo" />
        </div>
        <ul>
          <li className={openMenu === null ? "active" : ""}>
            <Link to="/admin">Home</Link>
          </li>
          <li
            onClick={() => toggleSubMenu("blog")}
            className={openMenu === "blog" ? "active" : ""}
          >
            <Link to="/add-blog">Blog</Link>{" "}
            <i className="fa fa-caret-down"></i>
          </li>
          {openMenu === "blog" && (
            <ol>
              <li>
                <Link to="/add-blog">Add Blog</Link>
              </li>
              <li>
                <Link to="/manage-blog">Manage Blog</Link>
              </li>
            </ol>
          )}
          <li
            onClick={() => toggleSubMenu("category")}
            className={openMenu === "category" ? "active" : ""}
          >
            <Link to="/add-category">Category</Link>{" "}
            <i className="fa fa-caret-down"></i>
          </li>
          {openMenu === "category" && (
            <ol>
              <li>
                <Link to="/add-category">Add Category</Link>
              </li>
              <li>
                <Link to="/manage-category">Manage Category</Link>
              </li>
            </ol>
          )}
          <li
            onClick={() => toggleSubMenu("speciality")}
            className={openMenu === "speciality" ? "active" : ""}
          >
            <Link to="/add-speciality">Speciality</Link>{" "}
            <i className="fa fa-caret-down"></i>
          </li>
          {openMenu === "speciality" && (
            <ol>
              <li>
                <Link to="/add-speciality">Add Speciality</Link>
              </li>
              <li>
                <Link to="/manage-speciality">Manage Speciality</Link>
              </li>
            </ol>
          )}
          <li
            onClick={() => toggleSubMenu("services")}
            className={openMenu === "services" ? "active" : ""}
          >
            <Link to="/add-service">Services</Link>{" "}
            <i className="fa fa-caret-down"></i>
          </li>
          {openMenu === "services" && (
            <ol>
              <li>
                <Link to="/add-service">Add Services</Link>
              </li>
              <li>
                <Link to="/manage-service">Manage Services</Link>
              </li>
            </ol>
          )}
          <li
            onClick={() => toggleSubMenu("doctors")}
            className={openMenu === "doctors" ? "active" : ""}
          >
            <Link to="/add-doctors">Doctors</Link>{" "}
            <i className="fa fa-caret-down"></i>
          </li>
          {openMenu === "doctors" && (
            <ol>
              <li>
                <Link to="/add-doctors">Add Doctors</Link>
              </li>
              <li>
                <Link to="/manage-doctors">Manage Doctors</Link>
              </li>
            </ol>
          )}
        </ul>
      </div>
    </div>
  );
}

export default List;
