import React, { useEffect, useState } from "react";
import { useAuth } from "../../store/auth";
import { useNavigate, useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import List from "./List";

function AddDoctor() {
  const { id } = useParams();
  const { authorizationToken, API } = useAuth();
  const navigate = useNavigate();
  const URL = `${API}/api/adminv2/doctors`;

  const [DoctorsData, setDoctorsData] = useState({
    drTitle: "",
    drDepartment: "",
    drSlug: "",
    drImage: null,
    drQualification: "",
    drTiming: "",
    drStatus: true,
  });

  const [categories, setCategories] = useState([]);

  const handleDoctorInput = (e) => {
    const { name, value } = e.target;

    let modifiedValue = value;

    if (name === "drSlug") {
      modifiedValue = value.toLowerCase().replace(/\s+/g, "-");
    }

    setDoctorsData({
      ...DoctorsData,
      [name]: modifiedValue,
    });
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API}/api/adminv1/view-category`, {
        method: "GET",
        headers: {
          Authorization: authorizationToken,
        },
      });
      if (response.ok) {
        const data = await response.json();
        setCategories(data.category);
      } else {
        throw new Error("Failed to fetch categories");
      }
    } catch (error) {
      console.error(error);
      // toast.error("Failed to fetch categories");
    }
  };

  const handleDrFileChange = (e) => {
    setDoctorsData({
      ...DoctorsData,
      drImage: e.target.files[0],
    });
  };

  const handleDoctors = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("drTitle", DoctorsData.drTitle);
    formData.append("drSlug", DoctorsData.drSlug);
    formData.append("drStatus", DoctorsData.drStatus);
    formData.append("drImage", DoctorsData.drImage);
    try {
      const method = id ? "PUT" : "POST";
      const response = await fetch(`${URL}/${id || ""}`, {
        method,
        headers: {
          Authorization: authorizationToken,
        },
        body: formData,
      });
      if (response.ok) {
        const message = id
          ? "Doctor updated successfully"
          : "Doctor added successfully";
        toast.success(message);
        const data = await response.json();
        console.log(data);
        toast.success("Doctor added successfully");
        setDoctorsData({
          drTitle: "",
          drDepartment: "",
          drSlug: "",
          drImage: null,
          drQualification: "",
          drTiming: "",
          drStatus: true,
        });
        navigate("/manage-doctors");
      } else {
        throw new Error("Failed to add doctor");
      }
    } catch (error) {
      console.error(error);
      toast.error("Failed to add doctor");
    }
  };

  return (
    <>
      <main>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-3 adminleft">
              <List />
            </div>
            <div className="col-md-9 adminright">
              <div className="addblog">
                <div className="addblogform">
                  <h2>
                    Add Doctor
                    <Link to="/manage-doctors" className="btn btn-light ss">
                      View Doctors
                    </Link>
                  </h2>
                  <form onSubmit={handleDoctors} encType="multipart/form-data">
                    <div className="row mt-4">
                      <div className="col-md-12">
                        <label htmlFor="drDepartment" className="form-label">
                          Doctor's Department
                        </label>
                        <select
                          name="drDepartment"
                          id="drDepartment"
                          value={DoctorsData.drDepartment}
                          onChange={handleDoctorInput}
                          className="form-control"
                          required
                        >
                          <option value="">Select Department</option>
                          {categories.map((category) => (
                            <option key={category._id} value={category._id}>
                              {category.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="row mt-4">
                      <div className="col-md-6">
                        <label htmlFor="drTitle" className="form-label">
                          Doctor's Name
                        </label>
                        <input
                          name="drTitle"
                          autoComplete="off"
                          value={DoctorsData.drTitle}
                          onChange={handleDoctorInput}
                          id="drTitle"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="drSlug" className="form-label">
                          Slug
                        </label>
                        <input
                          name="drSlug"
                          autoComplete="off"
                          value={DoctorsData.drSlug}
                          onChange={handleDoctorInput}
                          id="drSlug"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                    </div>
                    <div className="row mt-4">
                      <div className="col-md-6">
                        <label htmlFor="drQualification" className="form-label">
                          Doctor's Qualification
                        </label>
                        <input
                          name="drQualification"
                          autoComplete="off"
                          value={DoctorsData.drQualification}
                          onChange={handleDoctorInput}
                          id="drQualification"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="drTiming" className="form-label">
                          Doctor's Timing
                        </label>
                        <input
                          name="drTiming"
                          autoComplete="off"
                          value={DoctorsData.drTiming}
                          onChange={handleDoctorInput}
                          id="drTiming"
                          required
                          type="text"
                          className="form-control"
                        />
                      </div>
                    </div>
                    <div className="row mt-4">
                      <div className="col-md-6">
                        <label htmlFor="drImage" className="form-label">
                          Doctor's Image
                        </label>
                        <input
                          name="drImage"
                          autoComplete="off"
                          onChange={handleDrFileChange}
                          id="drImage"
                          required
                          type="file"
                          className="form-control"
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="drStatus" className="form-label">
                          Status
                        </label>
                        <select
                          name="drStatus"
                          value={DoctorsData.drStatus ? "true" : "false"}
                          onChange={handleDoctorInput}
                          id="drStatus"
                          className="form-select"
                        >
                          <option value="true">Active</option>
                          <option value="false">Inactive</option>
                        </select>
                      </div>
                    </div>
                    <div className="row mt-4">
                      <div className="col-md-12">
                        <button type="submit" className="btn btn-primary w-100">
                          Add Doctor
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default AddDoctor;
