import React from "react";
import List from "./List";
import TopBarAdmin from "./TopBarAdmin";
function Manageblog() {
  return (
    <>
      <main>
        <TopBarAdmin />
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-3 adminleft">
              <div>
                <List />
              </div>
            </div>
            <div class="col-md-9 adminright">
              <div className="addblog">
                <div>
                  <div className="addblogform">
                    <h2>Manage Blog</h2>
                    <div>
                      <table class="table table-dark">
                        <thead>
                          <tr>
                            <th scope="col">id</th>
                            <th scope="col">Title</th>
                            <th scope="col">Slug</th>
                            <th scope="col">Image</th>
                            <th scope="col">Update</th>
                            <th scope="col">Delete</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row">1</th>
                            <td>What Is Nephrology </td>
                            <td>what-is-nephrology </td>
                            <td>
                              <img src="Nephrology" alt="" srcset="" />
                            </td>
                            <td scope="col" className="updatebtn">
                              <i className="fa fa-edit"></i>
                            </td>
                            <td scope="col" className="deletebtn">
                              <i className="fa fa-trash-o"></i>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default Manageblog;
