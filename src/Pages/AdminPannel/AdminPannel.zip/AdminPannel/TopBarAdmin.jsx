import React from 'react'

function TopBarAdmin() {
  return (
    <section className="topbaradmin">
      <div className="flex">
        <h2 className='ps-5'>NEO HOSPITAL</h2>
        <div>
          <button className="btn btn-light">LogOut</button>
        </div>
      </div>
    </section>
  );
}

export default TopBarAdmin