import React, { useState, useEffect } from "react";
import List from "./List";
import TopBarAdmin from "./TopBarAdmin";
import { Link } from "react-router-dom";
import { useAuth } from "../../store/auth";
import { toast } from "react-toastify";

function ManageDoctor() {
  const [viewDoctorsData, setViewDoctorsData] = useState([]);
  const { authorizationToken, API } = useAuth();

  const getviewDoctorssData = async () => {
    try {
      const response = await fetch(`${API}/api/adminv2/view-doctors`, {
        method: "GET",
        headers: {
          Authorization: authorizationToken,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setViewDoctorsData(data.Doctor);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const deleteviewDoctorsById = async (id) => {
    try {
      const response = await fetch(`${API}/api/adminv2/doctors/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: authorizationToken,
        },
      });
      if (response.ok) {
        getviewDoctorssData();
        toast.success("Doctor deleted successfully");
      } else {
        toast.error("Failed to delete Doctor");
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getviewDoctorssData();
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Are you want to delete ?")) {
      deleteviewDoctorsById(id);
    }
  };

  return (
    <>
      <TopBarAdmin />
      <main>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-3 adminleft">
              <List />
            </div>
            <div className="col-md-9 adminright">
              <div className="addblog">
                <div className="addblogform">
                  <h2>
                    Manage Doctor
                    <Link to="/add-doctors" className="btn btn-light ss">
                      Add Doctor
                    </Link>
                  </h2>
                  <table className="table table-dark">
                    <thead>
                      <tr>
                        <th scope="col">id</th>
                        <th scope="col">Doctor Name</th>
                        <th scope="col">Qualification</th>
                        <th scope="col">Timing</th>
                        <th scope="col">Update</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {viewDoctorsData.map((doctor, index) => (
                        <tr key={index}>
                          <td>{index + 1}</td>
                          <td>{doctor.title}</td>
                          <td>{doctor.drQualification}</td>
                          <td>{doctor.drTiming}</td>
                          <td className="updatebtn">
                            <Link to={`/add-doctors/${doctor._id}`}>
                              <i className="fa fa-edit text-light"></i>
                            </Link>
                          </td>
                          <td className="deletebtn">
                            <button
                              className="btn"
                              onClick={() => handleDelete(doctor._id)}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default ManageDoctor;
