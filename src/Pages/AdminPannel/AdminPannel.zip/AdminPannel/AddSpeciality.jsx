import React from "react";
import List from "./List";
import TopBarAdmin from "./TopBarAdmin";

function AddSpecialitiy() {
  return (
      <>
          <TopBarAdmin />
      <main>
        <div className="container-fluid">
          <div class="row">
            <div class="col-md-3 adminleft">
              <div>
                <List />
              </div>
            </div>
            <div class="col-md-9 adminright">
              <div className="addblog">
                <div>
                  <div className="addblogform">
                    <h2>Add Specialities</h2>
                    <form>
                      <div className="row mt-4">
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Title
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Slug
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                      <div className="row mt-4">
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Date
                          </label>
                          <input type="date" class="form-control" />
                        </div>
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Auther
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                      <div className="row mt-4">
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Category
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Tags
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                      <div className="row mt-4">
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Meta Tittle
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Meta Description
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                      <div className="row mt-4">
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Canonical URL
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                        <div className="col-md-6">
                          <label for="inputEmail4" class="form-label">
                            Meta Keyword
                          </label>
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                      <div className="row mt-4">
                        <div className="col-md-12">
                          <label for="inputEmail4" class="form-label">
                            Content
                          </label>
                          <div className="contentbox">
                            <textarea rows="6"></textarea>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-4">
                        <div className="col-md-12">
                          <button
                            type="submit"
                            className="btn btn-primary w-100"
                          >
                            Add Specialities
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default AddSpecialitiy;
